from sklearn.model_selection import train_test_split
import constants as C
import cv2
import numpy as np
import os
import pickle


def load_image(parentDir, dataDir, name, num):
    path = parentDir + "\\" + dataDir + "\\" + name + "\\" + name + "_" + num.zfill(4) + ".jpg"
    img = cv2.imread(path, 0)
    img = cv2.resize(img, (C.IMG_HEIGHT, C.IMG_WIDTH))
    img = np.reshape(img, (C.IMG_HEIGHT, C.IMG_WIDTH, C.NUM_CHANNELS))
    return img


def images_to_arrays(line):
    fields = line.strip().split("\t")
    im1 = load_image(parentDir, dataDir, fields[0], fields[1])
    if len(fields) == 3:  # Same
        im2 = load_image(parentDir, dataDir, fields[0], fields[2])
        label = 1
    else:  # Different: len(fields) == 4
        im2 = load_image(parentDir, dataDir, fields[2], fields[3])
        label = 0
    return im1, im2, label


def file_to_dataset(file, dataset, label):
    with open(file) as f:
        next(f)
        i = 0
        for line in f:
            dataset[i][0], dataset[i][1], label[i] = images_to_arrays(line)
            i += 1
    return dataset, label


def print_label_info(label, name):
    num_pairs = label.size
    num_1s = (label == 1).sum()
    num_0s = (label == 0).sum()
    print(name + ":  #pairs = " + str(num_pairs) + "  #same = " + str(num_1s) +
          "  #different = " + str(num_0s) + ".")
    return


# parentDir = "C:\\Users\\ricks\PycharmProjects\DL_2"
parentDir = os.getcwd()
dataDir = "lfwa\lfw2\lfw2"
trainFile = os.path.join(parentDir, "pairsDevTrain.txt")
testFile = os.path.join(parentDir, "pairsDevTest.txt")

numPairsTrain = sum(1 for l in open(trainFile)) - 1
numPairsTest = sum(1 for l in open(testFile)) - 1

X = np.empty([numPairsTrain, 2, C.IMG_HEIGHT, C.IMG_HEIGHT, C.NUM_CHANNELS], dtype=int)
y = np.empty([numPairsTrain, 1], dtype=int)
X_test = np.empty([numPairsTest, 2, C.IMG_HEIGHT, C.IMG_HEIGHT, C.NUM_CHANNELS], dtype=int)
y_test = np.empty([numPairsTest, 1], dtype=int)

X, y = file_to_dataset(trainFile, X, y)
X_test, y_test = file_to_dataset(testFile, X_test, y_test)

X, X_test = X / 255.0, X_test / 255.0
test_size = 0.2  # proportion of validation/hold-out out of all train samples
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=test_size, shuffle=True)

# Print Info:
num_images = 0
for root, dirs, images in os.walk(dataDir):
    num_images += len(images)
print("Total no. of images: %d." % num_images)
print("Total no. of people: %d." % len(os.listdir(dataDir)))
print_label_info(y_train, "y_train")
print_label_info(y_val, "y_val")
print_label_info(y_test, "y_test")

# Create a data-structure (list) containing all datasets' numpy-arrays
# and saving it using "pickle"
Datasets = [X_train, y_train, X_val, y_val, X_test, y_test]

filename = "Datasets"  # Create datasets' file
outfile = open(filename, 'wb')
pickle.dump(Datasets, outfile)
outfile.close()
