from tensorflow.keras import backend as K
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.layers import Conv2D, Dense, Dropout, Flatten, Input, Lambda, AveragePooling2D, MaxPooling2D
from tensorflow.keras.models import Model, Sequential
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.regularizers import l2
import constants as C
import numpy as np
import matplotlib.pylab as plt
import pickle
import time


def W_C_init(shape, name=None, dtype=float):
    values = np.random.normal(loc=0, scale=0.01, size=shape)
    return K.variable(values, name=name)


def W_F_init(shape, name=None, dtype=float):
    values = np.random.normal(loc=0, scale=0.02, size=shape)
    return K.variable(values, name=name)


def b_init(shape, name=None, dtype=float):
    values = np.random.normal(loc=0.5, scale=0.01, size=shape)
    return K.variable(values, name=name)


def create_siamese_nn(input_shape):
    # Input layer
    x1 = Input(input_shape)
    x2 = Input(input_shape)

    cnn = Sequential()

    # Hidden layers
    cnn.add(Conv2D(64, (10, 10), activation='relu', kernel_initializer=W_C_init,
                   kernel_regularizer=l2(0.0002), input_shape=input_shape))
    # cnn.add(Dropout(0.2))
    cnn.add(MaxPooling2D())
    # cnn.add(AveragePooling2D())

    cnn.add(Conv2D(128, (7, 7), activation='relu', kernel_initializer=W_C_init,
                   kernel_regularizer=l2(0.0002), bias_initializer=b_init))
    # cnn.add(Dropout(0.2))
    cnn.add(MaxPooling2D())
    # cnn.add(AveragePooling2D())

    cnn.add(Conv2D(128, (4, 4), activation='relu', kernel_initializer=W_C_init,
                   kernel_regularizer=l2(0.0002), bias_initializer=b_init))
    # cnn.add(Dropout(0.2))
    cnn.add(MaxPooling2D())
    # cnn.add(AveragePooling2D())

    cnn.add(Conv2D(256, (4, 4), activation='relu', kernel_initializer=W_C_init,
                   kernel_regularizer=l2(0.0002), bias_initializer=b_init))

    cnn.add(Flatten())
    # cnn.add(Dropout(0.2))
    cnn.add(Dense(4096, activation='sigmoid', kernel_initializer=W_F_init,
                  kernel_regularizer=l2(0.001), bias_initializer=b_init))

    fv1 = cnn(x1)
    fv2 = cnn(x2)

    # Distance layer
    L1_layer = Lambda(lambda tensors: K.abs(tensors[0] - tensors[1]))
    L1_distance = L1_layer([fv1, fv2])

    # Output layer
    prediction = Dense(1, activation='sigmoid', kernel_initializer=W_F_init,
                       bias_initializer=b_init)(L1_distance)

    siamese = Model(inputs=[x1, x2], outputs=prediction)
    return siamese


siamese = create_siamese_nn((C.IMG_HEIGHT, C.IMG_WIDTH, C.NUM_CHANNELS))
siamese.summary()

optimizer = Adam(lr=0.0001)
siamese.compile(loss="binary_crossentropy", optimizer=optimizer, metrics=['accuracy'])

# Loading data + Training
filename = "Datasets"
infile = open(filename, 'rb')
X_train, y_train, X_val, y_val, X_test, y_test = pickle.load(infile)

callback = EarlyStopping(monitor='val_loss', mode='min', verbose=1, patience=1)
t_start = time.time()
results = siamese.fit([X_train[:, 0], X_train[:, 1]], y_train,
                      validation_data=([X_val[:, 0], X_val[:, 1]], y_val),
                      batch_size=C.BATCH_SIZE, epochs=5,
                      callbacks=[callback])

# Test
t = time.time() - t_start
loss, acc = siamese.evaluate([X_test[:, 0], X_test[:, 1]], y_test)
print("%s: %.3f[s]" % ('Convergence Time', t))
print("%s: %.3f" % ('Test Loss', loss))
print("%s: %.3f%%" % ('Test Accuracy', acc*100))

# Graphs:
fig, axs = plt.subplots(1, 2)
x = list(range(1, len(results.history['val_loss']) + 1))  # Epochs' axis (until stopping)

# Loss graph
axs[0].plot(x, results.history['loss'])
axs[0].plot(x, results.history['val_loss'])
axs[0].set(xlabel='Epoch #', ylabel='Loss', title='Loss')
axs[0].legend(['Train', 'Validation'], loc='upper right')

# Accuracy graph
axs[1].plot(x, [y * 100 for y in results.history['accuracy']])
axs[1].plot(x, [y * 100 for y in results.history['val_accuracy']])
axs[1].set(xlabel='Epoch #', ylabel='Accuracy [%]', title='Accuracy [%]')
axs[1].legend(['Train', 'Validation'], loc='upper right')

plt.tight_layout()
plt.show()
